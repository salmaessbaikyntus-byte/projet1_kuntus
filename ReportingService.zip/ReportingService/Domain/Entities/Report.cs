namespace ReportingService.Domain.Entities
{
    public class Report
    {
        // On change l'ID en Guid pour correspondre au contrôleur
        public Guid Id { get; set; } 
        
        public required string Type { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public required string GeneratedBy { get; set; }
        public required string FilePath { get; set; }
        
        // On ajoute la propriété manquante demandée par l'erreur CS0117
        public Guid PlanningId { get; set; } 
    }
}