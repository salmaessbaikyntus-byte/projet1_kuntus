using ReportingService.Domain.Entities;
using ReportingService.Application.Interfaces;

namespace ReportingService.Application.Services
{
    public class ReportGenerationService
    {
        private readonly IReportRepository _repository;

        public ReportGenerationService(IReportRepository repository)
        {
            _repository = repository;
        }

        public async Task<Report> GenerateAsync(Guid planningId, string type, string generatedBy)
        {
            var report = new Report
            {
                Id = Guid.NewGuid(),
                PlanningId = planningId,
                Type = type,
                CreatedAt = DateTime.UtcNow,
                GeneratedBy = generatedBy,
                FilePath = $"GeneratedReports/{Guid.NewGuid()}.{type.ToLower()}"
            };

            await _repository.AddAsync(report);

            return report;
        }
    }
}
