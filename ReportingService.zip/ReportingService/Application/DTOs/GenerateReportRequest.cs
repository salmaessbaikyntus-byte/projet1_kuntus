namespace ReportingService.Application.DTOs
{
    public class GenerateReportRequest
    {
        public Guid PlanningId { get; set; }
        public string Type { get; set; } = "PDF";
        public string GeneratedBy { get; set; } = "RH";
    }
}
