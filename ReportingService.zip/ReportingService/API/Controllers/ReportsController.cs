using Microsoft.AspNetCore.Mvc;
using ReportingService.Application.DTOs;
using ReportingService.Application.Services;
using ReportingService.Application.Interfaces;

namespace ReportingService.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReportsController : ControllerBase
    {
        private readonly ReportGenerationService _generationService;
        private readonly IReportRepository _repository;

        public ReportsController(
            ReportGenerationService generationService,
            IReportRepository repository)
        {
            _generationService = generationService;
            _repository = repository;
        }

        [HttpPost("generate")]
        public async Task<IActionResult> Generate(GenerateReportRequest request)
        {
            var report = await _generationService.GenerateAsync(
                request.PlanningId,
                request.Type,
                request.GeneratedBy);

            return Ok(report);
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var reports = await _repository.GetAllAsync();
            return Ok(reports);
        }
    }
}
