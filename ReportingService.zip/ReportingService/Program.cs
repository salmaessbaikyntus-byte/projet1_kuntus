using Microsoft.EntityFrameworkCore;
using ReportingService.Infrastructure.Data;
using ReportingService.Application.Interfaces;
using ReportingService.Infrastructure.Repositories;
using ReportingService.Application.Services;

AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);
var builder = WebApplication.CreateBuilder(args);

// Indispensable pour PostgreSQL et les dates

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(); // Maintenant cela va fonctionner !
builder.Services.AddScoped<ReportGenerationService>();


builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddScoped<IReportRepository, ReportRepository>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();
app.MapControllers();

app.Run();